<template>
  <div class='container' v-bind:class="{loginned: isLoginned, notLoginned : isNotLoginned}">
    <h1 id="title">{{name}}</h1>
    <div  class="imgCard">{{img}}</div>
    <div class="description">
        <p>{{name}} {{description}}</p>
    </div>
    <div class="form">
        <input v-model="name" type="text">
        <input v-model="img" class="inputImg" type="text">
        <input v-model="description" type="text">
    </div>
    <button v-on:click="submit" class="btn">go</button>
    
    <tabs-btn></tabs-btn>
  </div>
</template>

<script>
import tabFirstVue from './components/tab-first.vue';
import tabsBtnVue from './components/tabs-btn.vue';
// import appVue from '';

export default {
  name: 'App',

  components: {
    tabsBtn: tabsBtnVue,
    first: tabFirstVue,
    // second: appVue
  },

  data() {
    return {
      name: 'Крокодил',
      img: '1',
      description: 'ебёт гусей',
      isNotLoginned: true,
      isLoginned: false,
    }
  },
  methods: {
    submit: function () {
      if (this.description === 'ква') {
          this.isLoginned = true;
          this.isNotLoginned = false;
      } else {
          this.isLoggined = false;
          this.isNotLoginned = true;
      }
    }
  }
};
</script>


















<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap');

* {
    margin: 0px;
    padding: 0px;
    list-style-type: none;
    text-decoration: none;
    font-family: 'Roboto', sans-serif;
    word-wrap: break-word;
}
button {
  background-color: #fff;
}

/* #app {
    background: no-repeat url(img/bg-login-0.jpeg);
    width: 100%;
    background-size: contain;
    background-position: 50%;
} */

.container {
    display: block;
    width: 400px;
    height: 500px;
    margin: 0 auto;
    margin-top: 50px;
    border: 1px solid black;
    border-radius: 5%;
}
#title {
    padding: 4px 10px;
    text-align: center;
}
.imgCard {
    
}
.description {
    padding: 5px;
}
.form {
    margin: 10px auto;
    width: 400px;
    height: 67px;
}
.form input {
    display: flex;
    margin: 5px auto;
    background-color: rgba(255, 255, 255, 0.5);
}
.btn {
    display: block;
    width: 100px;
    height: 20px;
    margin: 10px auto;
}
.loginned {
    background: no-repeat url(./assets/bg-login-1.jpeg);
    background-size: contain;
    background-position: 50%;
}
.notLoginned {
    background: no-repeat url(./assets/bg-login-0.jpeg);
    background-size: contain;
    background-position: 50%;
}
</style>